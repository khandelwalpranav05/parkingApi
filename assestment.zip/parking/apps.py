from django.apps import AppConfig


class ParkingConfig(AppConfig):
    name = 'parking'
